// Subsistemas
class CPU {
    public void process() {
        System.out.println("CPU is processing...");
    }
}

class Memory {
    public void load() {
        System.out.println("Memory is loading...");
    }
}

class HardDrive {
    public void read() {
        System.out.println("Hard drive is reading...");
    }
}

// Facade
class ComputerFacade {
    private CPU cpu;
    private Memory memory;
    private HardDrive hardDrive;

    public ComputerFacade() {
        this.cpu = new CPU();
        this.memory = new Memory();
        this.hardDrive = new HardDrive();
    }

    public void startup() {
        System.out.println("Starting up the computer...");
        cpu.process();
        memory.load();
        hardDrive.read();
        System.out.println("Startup complete.");
    }

    public void shutdown() {
        System.out.println("Shutting down the computer...");
        cpu.process();
        memory.load();
        hardDrive.read();
        System.out.println("Shutdown complete.");
    }
}

public class Main {
    public static void main(String[] args) {
        ComputerFacade computer = new ComputerFacade();
        computer.startup();
        System.out.println();
        computer.shutdown();
    }
}
