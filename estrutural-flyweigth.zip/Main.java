// Flyweight
class CharacterFlyweight {
    private final char character;

    public CharacterFlyweight(char character) {
        this.character = character;
    }

    public void display(int x, int y) {
        System.out.println("Displaying character '" + character + "' at (" + x + ", " + y + ")");
    }
}

// Flyweight Factory
class CharacterFactory {
    private static final java.util.Map<Character, CharacterFlyweight> characterMap = new java.util.HashMap<>();

    public static CharacterFlyweight getCharacter(char character) {
        if (!characterMap.containsKey(character)) {
            CharacterFlyweight newCharacter = new CharacterFlyweight(character);
            characterMap.put(character, newCharacter);
        }
        return characterMap.get(character);
    }
}

public class Main {
    public static void main(String[] args) {
        CharacterFlyweight a = CharacterFactory.getCharacter('A');
        CharacterFlyweight b = CharacterFactory.getCharacter('B');
        CharacterFlyweight a1 = CharacterFactory.getCharacter('A');

        a.display(10, 10);
        b.display(20, 20);
        a1.display(30, 30);
    }
}