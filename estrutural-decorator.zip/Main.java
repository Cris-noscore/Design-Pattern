// Componente
interface Pizza {
    double getCost();
    String getDescription();
}

// Componente Concreto
class BasePizza implements Pizza {
    @Override
    public double getCost() {
        return 10.0;
    }

    @Override
    public String getDescription() {
        return "Base Pizza";
    }
}

// Decorator Abstrato
abstract class PizzaDecorator implements Pizza {
    protected Pizza pizza;

    public PizzaDecorator(Pizza pizza) {
        this.pizza = pizza;
    }

    @Override
    public double getCost() {
        return pizza.getCost();
    }

    @Override
    public String getDescription() {
        return pizza.getDescription();
    }
}

// Decoradores Concretos
class CheeseTopping extends PizzaDecorator {
    public CheeseTopping(Pizza pizza) {
        super(pizza);
    }

    @Override
    public double getCost() {
        return super.getCost() + 2.0;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + ", Cheese Topping";
    }
}

class PepperoniTopping extends PizzaDecorator {
    public PepperoniTopping(Pizza pizza) {
        super(pizza);
    }

    @Override
    public double getCost() {
        return super.getCost() + 3.0;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + ", Pepperoni Topping";
    }
}

public class Main {
    public static void main(String[] args) {
        Pizza pizza = new BasePizza();
        System.out.println("Pizza: " + pizza.getDescription() + ", Cost: $" + pizza.getCost());

        pizza = new CheeseTopping(pizza);
        System.out.println("Pizza: " + pizza.getDescription() + ", Cost: $" + pizza.getCost());

        pizza = new PepperoniTopping(pizza);
        System.out.println("Pizza: " + pizza.getDescription() + ", Cost: $" + pizza.getCost());
    }
}
